import { Link } from 'react-router-dom';
import {
  Scale, Users, TrendingUp, Calendar, Star, ChevronRight,
  MapPin, Phone, Mail, Clock, Award, Shield, Gavel,
  BookOpen, ArrowRight, CheckCircle, Quote
} from 'lucide-react';

const stats = [
  { icon: Users, number: '1500+', label: 'Happy Clients', color: 'bg-blue-500' },
  { icon: TrendingUp, number: '95%', label: 'Success Rate', color: 'bg-green-500' },
  { icon: Calendar, number: '5+', label: 'Years Experience', color: 'bg-accent' },
  { icon: Award, number: '2000+', label: 'Cases Handled', color: 'bg-purple-500' },
];

const expertise = [
  { name: 'Divorce Lawyer', icon: Scale, desc: 'Expert handling of divorce proceedings with sensitivity and legal precision.' },
  { name: 'Criminal Lawyer', icon: Shield, desc: 'Aggressive defense strategies to protect your rights in criminal cases.' },
  { name: 'Civil Lawyer', icon: Gavel, desc: 'Comprehensive civil litigation services for disputes and resolutions.' },
  { name: 'Corporate Lawyer', icon: BookOpen, desc: 'Strategic corporate legal advisory for businesses of all sizes.' },
];

const reviews = [
  {
    name: 'Rajesh Kumar',
    role: 'Business Owner',
    text: 'Legal Edge Associates handled my corporate dispute with exceptional professionalism. Their team was thorough, responsive, and achieved a favorable outcome. Highly recommended!',
    rating: 5,
  },
  {
    name: 'Priya Sharma',
    role: 'Software Engineer',
    text: 'During a difficult divorce, the lawyers at Legal Edge were compassionate yet firm. They guided me through every step and ensured my rights were protected. Truly grateful.',
    rating: 5,
  },
  {
    name: 'Amit Verma',
    role: 'Property Dealer',
    text: 'I approached them for a property dispute that had been dragging for years. Within months, they resolved it efficiently. Their knowledge of property law is outstanding.',
    rating: 5,
  },
  {
    name: 'Sunita Devi',
    role: 'Homemaker',
    text: 'The team helped me with a domestic violence case. They were sensitive to my situation and fought tirelessly for justice. I felt safe and supported throughout.',
    rating: 5,
  },
  {
    name: 'Vikram Singh',
    role: 'Entrepreneur',
    text: 'Excellent legal advice for my startup. From incorporation to compliance, they covered everything. Their corporate law expertise is top-notch and affordable.',
    rating: 5,
  },
  {
    name: 'Meera Patel',
    role: 'Teacher',
    text: 'Consumer dispute resolved in my favor thanks to Legal Edge. They explained the process clearly and kept me updated at every stage. Very professional service.',
    rating: 4,
  },
];

const newsAndTips = [
  {
    category: 'Legal Update',
    title: 'New Amendments in Family Law 2024',
    excerpt: 'The government has introduced significant amendments to family law provisions affecting divorce proceedings and child custody arrangements.',
    date: 'Dec 15, 2024',
  },
  {
    category: 'Legal Tips',
    title: '5 Things to Know Before Filing a Property Dispute',
    excerpt: 'Property disputes can be complex. Understanding these key aspects before filing can save you time, money, and stress.',
    date: 'Dec 10, 2024',
  },
  {
    category: 'News',
    title: 'Supreme Court Landmark Judgment on Cyber Law',
    excerpt: 'The Supreme Court delivered a groundbreaking judgment strengthening the legal framework for cyber crime victims and digital privacy rights.',
    date: 'Dec 05, 2024',
  },
];

const Home = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="hero-gradient relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-accent rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-blue-400 rounded-full blur-3xl"></div>
        </div>
        <div className="max-w-7xl mx-auto px-4 py-24 md:py-36 relative z-10">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="animate-slide-in-left">
              <div className="inline-flex items-center gap-2 bg-accent/20 text-accent px-4 py-2 rounded-full text-sm font-medium mb-6">
                <Scale size={16} />
                Trusted Legal Solutions Since 2019
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6" style={{ fontFamily: 'Georgia, serif' }}>
                Justice You Deserve, <br />
                <span className="text-accent">Advocacy You Trust</span>
              </h1>
              <p className="text-gray-300 text-lg mb-8 leading-relaxed max-w-lg">
                We provide expert legal representation across all courts in Delhi. Our experienced team of lawyers is dedicated to protecting your rights and delivering results.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link
                  to="/contact"
                  className="bg-accent hover:bg-accent-light text-white px-8 py-3.5 rounded-md font-semibold transition-all duration-300 shadow-lg hover:shadow-xl flex items-center gap-2"
                >
                  Book Free Consultation
                  <ChevronRight size={18} />
                </Link>
                <Link
                  to="/our-expertise"
                  className="border-2 border-white/30 hover:border-accent text-white px-8 py-3.5 rounded-md font-semibold transition-all duration-300 hover:bg-accent/10"
                >
                  Our Expertise
                </Link>
              </div>
            </div>
            <div className="hidden md:flex justify-center animate-slide-in-right">
              <div className="relative">
                <div className="w-80 h-80 lg:w-96 lg:h-96 bg-accent/20 rounded-full flex items-center justify-center border-2 border-accent/30">
                  <div className="w-64 h-64 lg:w-80 lg:h-80 bg-accent/10 rounded-full flex items-center justify-center border border-accent/20">
                    <Scale className="text-accent" size={120} />
                  </div>
                </div>
                <div className="absolute -top-4 -right-4 bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20">
                  <div className="text-accent text-2xl font-bold">95%</div>
                  <div className="text-white text-xs">Success Rate</div>
                </div>
                <div className="absolute -bottom-4 -left-4 bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20">
                  <div className="text-accent text-2xl font-bold">1500+</div>
                  <div className="text-white text-xs">Happy Clients</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-white py-16 relative -mt-1">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <div
                key={index}
                className="bg-lighter rounded-xl p-6 text-center card-hover shadow-md border border-gray-100"
              >
                <div className={`${stat.color} w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg`}>
                  <stat.icon className="text-white" size={28} />
                </div>
                <div className="text-3xl md:text-4xl font-bold text-primary mb-2" style={{ fontFamily: 'Georgia, serif' }}>
                  {stat.number}
                </div>
                <div className="text-gray-500 text-sm font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Preview Section */}
      <section className="py-20 bg-lighter">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="relative">
                <div className="bg-primary rounded-2xl p-12 text-center">
                  <Scale className="text-accent mx-auto mb-4" size={80} />
                  <div className="text-white text-2xl font-bold" style={{ fontFamily: 'Georgia, serif' }}>5+ Years</div>
                  <div className="text-gray-300">of Legal Excellence</div>
                </div>
                <div className="absolute -bottom-6 -right-6 bg-accent rounded-xl p-4 shadow-xl">
                  <div className="text-white text-xl font-bold">2000+</div>
                  <div className="text-white/80 text-xs">Cases Won</div>
                </div>
              </div>
            </div>
            <div>
              <span className="text-accent font-semibold text-sm tracking-wider uppercase">About Us</span>
              <h2 className="text-3xl md:text-4xl font-bold text-primary mt-2 mb-6" style={{ fontFamily: 'Georgia, serif' }}>
                Dedicated to Delivering Justice with Integrity
              </h2>
              <p className="text-gray-600 mb-4 leading-relaxed">
                Legal Edge Associates is a premier law firm based in New Delhi, offering comprehensive legal solutions across multiple practice areas. Founded in 2019, we have built a reputation for excellence, integrity, and unwavering commitment to our clients.
              </p>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Our team of experienced lawyers specializes in family law, criminal defense, civil litigation, corporate law, and more. We believe every client deserves personalized attention and strategic legal representation.
              </p>
              <ul className="space-y-3 mb-8">
                {['Client-Centered Approach', 'Transparent Communication', 'Proven Track Record', 'Affordable Legal Services'].map((item) => (
                  <li key={item} className="flex items-center gap-3 text-gray-700">
                    <CheckCircle className="text-accent shrink-0" size={20} />
                    <span className="font-medium">{item}</span>
                  </li>
                ))}
              </ul>
              <Link
                to="/about"
                className="inline-flex items-center gap-2 bg-primary hover:bg-primary-light text-white px-8 py-3 rounded-md font-semibold transition-all duration-300"
              >
                Learn More About Us
                <ArrowRight size={18} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Expertise Preview Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-14">
            <span className="text-accent font-semibold text-sm tracking-wider uppercase">What We Excel At</span>
            <h2 className="text-3xl md:text-4xl font-bold text-primary mt-2 mb-4" style={{ fontFamily: 'Georgia, serif' }}>
              Our Areas of Expertise
            </h2>
            <p className="text-gray-500 max-w-2xl mx-auto">
              We bring deep knowledge and extensive experience across diverse legal domains to provide you with the best possible representation.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {expertise.map((item, index) => (
              <div
                key={index}
                className="bg-lighter rounded-xl p-6 card-hover border border-gray-100 group"
              >
                <div className="bg-primary/10 group-hover:bg-accent w-14 h-14 rounded-lg flex items-center justify-center mb-4 transition-all duration-300">
                  <item.icon className="text-primary group-hover:text-white" size={26} />
                </div>
                <h3 className="text-lg font-bold text-primary mb-2">{item.name}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-10">
            <Link
              to="/our-expertise"
              className="inline-flex items-center gap-2 bg-accent hover:bg-accent-light text-white px-8 py-3 rounded-md font-semibold transition-all duration-300"
            >
              View All Expertise
              <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>

      {/* Client Reviews Section */}
      <section className="py-20 bg-primary relative overflow-hidden">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute top-10 right-20 w-96 h-96 bg-accent rounded-full blur-3xl"></div>
        </div>
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <div className="text-center mb-14">
            <span className="text-accent font-semibold text-sm tracking-wider uppercase">Testimonials</span>
            <h2 className="text-3xl md:text-4xl font-bold text-white mt-2 mb-4" style={{ fontFamily: 'Georgia, serif' }}>
              What Our Clients Say
            </h2>
            <p className="text-gray-300 max-w-2xl mx-auto">
              Our clients' satisfaction speaks volumes about our commitment to delivering exceptional legal services.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {reviews.map((review, index) => (
              <div
                key={index}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/10 card-hover"
              >
                <Quote className="text-accent mb-4" size={32} />
                <p className="text-gray-200 text-sm leading-relaxed mb-6">{review.text}</p>
                <div className="flex items-center gap-1 mb-4">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      size={16}
                      className={i < review.rating ? 'text-accent fill-accent' : 'text-gray-500'}
                    />
                  ))}
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-accent rounded-full flex items-center justify-center text-white font-bold text-sm">
                    {review.name.charAt(0)}
                  </div>
                  <div>
                    <div className="text-white font-semibold text-sm">{review.name}</div>
                    <div className="text-gray-400 text-xs">{review.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Book Appointment Section */}
      <section className="py-20 bg-lighter">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <span className="text-accent font-semibold text-sm tracking-wider uppercase">Get Started</span>
              <h2 className="text-3xl md:text-4xl font-bold text-primary mt-2 mb-6" style={{ fontFamily: 'Georgia, serif' }}>
                Book Your Free Consultation Today
              </h2>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Take the first step towards resolving your legal matters. Our expert lawyers are ready to listen to your case and provide you with the guidance you need. No obligations, no fees for the initial consultation.
              </p>
              <div className="space-y-4 mb-8">
                <div className="flex items-center gap-4">
                  <div className="bg-accent/10 w-12 h-12 rounded-lg flex items-center justify-center shrink-0">
                    <Phone className="text-accent" size={22} />
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Call Us Anytime</div>
                    <div className="text-primary font-semibold">+91 98765 43210</div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="bg-accent/10 w-12 h-12 rounded-lg flex items-center justify-center shrink-0">
                    <Mail className="text-accent" size={22} />
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Email Us</div>
                    <div className="text-primary font-semibold">info@legaledgeassociates.com</div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="bg-accent/10 w-12 h-12 rounded-lg flex items-center justify-center shrink-0">
                    <Clock className="text-accent" size={22} />
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Working Hours</div>
                    <div className="text-primary font-semibold">Mon - Sat: 10:00 AM - 7:00 PM</div>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div className="bg-white rounded-2xl p-8 shadow-xl border border-gray-100">
                <h3 className="text-xl font-bold text-primary mb-6" style={{ fontFamily: 'Georgia, serif' }}>
                  Schedule Appointment
                </h3>
                <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                  <div>
                    <input
                      type="text"
                      placeholder="Full Name"
                      className="w-full px-4 py-3 rounded-md border border-gray-200 focus:border-accent focus:outline-none text-sm transition-colors"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <input
                      type="email"
                      placeholder="Email Address"
                      className="w-full px-4 py-3 rounded-md border border-gray-200 focus:border-accent focus:outline-none text-sm transition-colors"
                    />
                    <input
                      type="tel"
                      placeholder="Phone Number"
                      className="w-full px-4 py-3 rounded-md border border-gray-200 focus:border-accent focus:outline-none text-sm transition-colors"
                    />
                  </div>
                  <div>
                    <select className="w-full px-4 py-3 rounded-md border border-gray-200 focus:border-accent focus:outline-none text-sm text-gray-500 transition-colors">
                      <option>Select Legal Area</option>
                      <option>Family Law</option>
                      <option>Criminal Law</option>
                      <option>Civil Law</option>
                      <option>Corporate Law</option>
                      <option>Property Law</option>
                      <option>Cyber Law</option>
                      <option>Other</option>
                    </select>
                  </div>
                  <div>
                    <textarea
                      rows={4}
                      placeholder="Brief Description of Your Case"
                      className="w-full px-4 py-3 rounded-md border border-gray-200 focus:border-accent focus:outline-none text-sm transition-colors resize-none"
                    ></textarea>
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-accent hover:bg-accent-light text-white py-3.5 rounded-md font-semibold transition-all duration-300 shadow-md"
                  >
                    Book Appointment Now
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* News, Tips & Legal Updates Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-14">
            <span className="text-accent font-semibold text-sm tracking-wider uppercase">Stay Informed</span>
            <h2 className="text-3xl md:text-4xl font-bold text-primary mt-2 mb-4" style={{ fontFamily: 'Georgia, serif' }}>
              News, Tips & Legal Updates
            </h2>
            <p className="text-gray-500 max-w-2xl mx-auto">
              Stay updated with the latest legal developments, expert tips, and important news that may affect your legal rights.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {newsAndTips.map((item, index) => (
              <div
                key={index}
                className="bg-lighter rounded-xl overflow-hidden card-hover border border-gray-100 group"
              >
                <div className="bg-primary p-6 relative">
                  <div className="absolute top-4 right-4 bg-accent text-white text-xs font-bold px-3 py-1 rounded-full">
                    {item.category}
                  </div>
                  <BookOpen className="text-accent/30" size={48} />
                </div>
                <div className="p-6">
                  <div className="text-gray-400 text-xs mb-3">{item.date}</div>
                  <h3 className="text-lg font-bold text-primary mb-3 group-hover:text-accent transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-gray-500 text-sm leading-relaxed mb-4">{item.excerpt}</p>
                  <Link
                    to="/blog"
                    className="text-accent font-semibold text-sm flex items-center gap-1 hover:gap-2 transition-all"
                  >
                    Read More <ArrowRight size={14} />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Location Section */}
      <section className="py-20 bg-lighter">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <span className="text-accent font-semibold text-sm tracking-wider uppercase">Find Us</span>
              <h2 className="text-3xl md:text-4xl font-bold text-primary mt-2 mb-6" style={{ fontFamily: 'Georgia, serif' }}>
                Visit Our Office
              </h2>
              <p className="text-gray-600 mb-8 leading-relaxed">
                Our office is conveniently located in the heart of New Delhi, easily accessible by public transport. We welcome walk-in consultations and scheduled appointments.
              </p>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="bg-accent w-12 h-12 rounded-lg flex items-center justify-center shrink-0">
                    <MapPin className="text-white" size={22} />
                  </div>
                  <div>
                    <div className="text-primary font-semibold mb-1">Our Address</div>
                    <div className="text-gray-500 text-sm">123 Legal Chambers, Connaught Place, New Delhi - 110001, India</div>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="bg-accent w-12 h-12 rounded-lg flex items-center justify-center shrink-0">
                    <Phone className="text-white" size={22} />
                  </div>
                  <div>
                    <div className="text-primary font-semibold mb-1">Call Us</div>
                    <div className="text-gray-500 text-sm">+91 98765 43210 / +91 11 2345 6789</div>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="bg-accent w-12 h-12 rounded-lg flex items-center justify-center shrink-0">
                    <Clock className="text-white" size={22} />
                  </div>
                  <div>
                    <div className="text-primary font-semibold mb-1">Office Hours</div>
                    <div className="text-gray-500 text-sm">Monday - Saturday: 10:00 AM - 7:00 PM</div>
                    <div className="text-gray-500 text-sm">Sunday: By Appointment Only</div>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div className="bg-primary rounded-2xl p-8 shadow-xl">
                <div className="bg-primary-light rounded-xl p-6 text-center">
                  <MapPin className="text-accent mx-auto mb-4" size={48} />
                  <h3 className="text-white text-xl font-bold mb-2" style={{ fontFamily: 'Georgia, serif' }}>
                    Our Location
                  </h3>
                  <p className="text-gray-300 text-sm mb-4">123 Legal Chambers, Connaught Place</p>
                  <p className="text-gray-300 text-sm mb-6">New Delhi - 110001, India</p>
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div className="bg-white/10 rounded-lg p-3">
                      <div className="text-accent text-lg font-bold">2 min</div>
                      <div className="text-gray-300 text-xs">From Metro</div>
                    </div>
                    <div className="bg-white/10 rounded-lg p-3">
                      <div className="text-accent text-lg font-bold">5 min</div>
                      <div className="text-gray-300 text-xs">From Bus Stop</div>
                    </div>
                  </div>
                  <Link
                    to="/contact"
                    className="inline-flex items-center gap-2 bg-accent hover:bg-accent-light text-white px-6 py-3 rounded-md font-semibold transition-all duration-300 mt-6"
                  >
                    Get Directions
                    <ArrowRight size={16} />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-accent">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4" style={{ fontFamily: 'Georgia, serif' }}>
            Need Legal Assistance? We're Here to Help
          </h2>
          <p className="text-white/80 max-w-2xl mx-auto mb-8">
            Don't face your legal challenges alone. Contact us today for a free consultation and let our experienced team fight for your rights.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link
              to="/contact"
              className="bg-primary hover:bg-primary-light text-white px-8 py-3.5 rounded-md font-semibold transition-all duration-300 shadow-lg"
            >
              Contact Us Now
            </Link>
            <a
              href="tel:+919876543210"
              className="bg-white hover:bg-gray-100 text-primary px-8 py-3.5 rounded-md font-semibold transition-all duration-300 shadow-lg flex items-center gap-2"
            >
              <Phone size={18} />
              Call +91 98765 43210
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
