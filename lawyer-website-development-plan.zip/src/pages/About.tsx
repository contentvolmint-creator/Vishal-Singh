import { Link } from 'react-router-dom';
import {
  Scale, Users, Target, Eye, Heart, Shield, CheckCircle,
  Award, ArrowRight, Gavel
} from 'lucide-react';

const values = [
  {
    icon: Shield,
    title: 'Integrity',
    desc: 'We uphold the highest ethical standards in every case we handle, ensuring complete transparency with our clients.',
  },
  {
    icon: Heart,
    title: 'Compassion',
    desc: 'We understand the emotional toll of legal disputes and treat every client with empathy and respect.',
  },
  {
    icon: Target,
    title: 'Excellence',
    desc: 'We pursue the best possible outcomes through meticulous preparation, strategic thinking, and relentless advocacy.',
  },
  {
    icon: Users,
    title: 'Client First',
    desc: 'Your interests always come first. We tailor our approach to meet your specific needs and goals.',
  },
];

const team = [
  {
    name: 'Adv. Arun Mehta',
    role: 'Founding Partner & Senior Advocate',
    specialization: 'Criminal Law & Supreme Court Practice',
    experience: '15+ Years Experience',
  },
  {
    name: 'Adv. Sunita Reddy',
    role: 'Managing Partner',
    specialization: 'Family Law & Matrimonial Disputes',
    experience: '12+ Years Experience',
  },
  {
    name: 'Adv. Rajiv Kapoor',
    role: 'Senior Associate',
    specialization: 'Corporate Law & Civil Litigation',
    experience: '10+ Years Experience',
  },
  {
    name: 'Adv. Neeta Sharma',
    role: 'Associate Partner',
    specialization: 'Property Law & RERA Matters',
    experience: '8+ Years Experience',
  },
  {
    name: 'Adv. Deepak Verma',
    role: 'Associate',
    specialization: 'Cyber Law & Consumer Disputes',
    experience: '6+ Years Experience',
  },
  {
    name: 'Adv. Kavita Singh',
    role: 'Associate',
    specialization: 'Domestic Violence & Bail Matters',
    experience: '5+ Years Experience',
  },
];

const milestones = [
  { year: '2019', event: 'Founded Legal Edge Associates in New Delhi' },
  { year: '2020', event: 'Expanded to handle over 500 cases across multiple practice areas' },
  { year: '2021', event: 'Recognized as a top emerging law firm in Delhi NCR' },
  { year: '2022', event: 'Opened new office in Connaught Place with a team of 10+ lawyers' },
  { year: '2023', event: 'Handled 1500+ cases with a 95% success rate' },
  { year: '2024', event: 'Expanded expertise to Cyber Law, RERA, and Consumer Disputes' },
];

const About = () => {
  return (
    <div>
      {/* Hero */}
      <section className="hero-gradient py-20 md:py-28">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="inline-flex items-center gap-2 bg-accent/20 text-accent px-4 py-2 rounded-full text-sm font-medium mb-6">
            <Scale size={16} />
            About Us
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4" style={{ fontFamily: 'Georgia, serif' }}>
            Who We Are
          </h1>
          <p className="text-gray-300 max-w-2xl mx-auto text-lg">
            A dedicated team of legal professionals committed to providing exceptional legal services with integrity, compassion, and excellence.
          </p>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <span className="text-accent font-semibold text-sm tracking-wider uppercase">Our Story</span>
              <h2 className="text-3xl md:text-4xl font-bold text-primary mt-2 mb-6" style={{ fontFamily: 'Georgia, serif' }}>
                Built on a Foundation of Trust & Legal Excellence
              </h2>
              <p className="text-gray-600 mb-4 leading-relaxed">
                Legal Edge Associates was founded in 2019 with a singular vision — to make quality legal representation accessible to everyone. What started as a small practice with two dedicated lawyers has grown into a full-service law firm with a team of over 10 experienced advocates.
              </p>
              <p className="text-gray-600 mb-4 leading-relaxed">
                Our founders, Adv. Arun Mehta and Adv. Sunita Reddy, brought together decades of legal expertise with a shared commitment to client welfare. They envisioned a firm where every client, regardless of the size of their case, would receive the same level of dedication and professional service.
              </p>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Today, we are proud to have served over 1500 clients across diverse legal domains, maintaining a success rate of 95%. Our growth is a testament to the trust our clients place in us and the results we consistently deliver.
              </p>
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-lighter rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-accent">1500+</div>
                  <div className="text-gray-500 text-xs mt-1">Happy Clients</div>
                </div>
                <div className="bg-lighter rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-accent">95%</div>
                  <div className="text-gray-500 text-xs mt-1">Success Rate</div>
                </div>
                <div className="bg-lighter rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-accent">5+</div>
                  <div className="text-gray-500 text-xs mt-1">Years Exp.</div>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="bg-primary rounded-2xl p-10 text-center">
                <Gavel className="text-accent mx-auto mb-6" size={80} />
                <h3 className="text-white text-2xl font-bold mb-2" style={{ fontFamily: 'Georgia, serif' }}>Our Mission</h3>
                <p className="text-gray-300 leading-relaxed">
                  To provide accessible, affordable, and exceptional legal services that protect our clients' rights and deliver justice with integrity.
                </p>
              </div>
              <div className="absolute -bottom-6 -left-6 bg-accent rounded-xl p-5 shadow-xl">
                <Award className="text-white mb-2" size={28} />
                <div className="text-white text-sm font-bold">Recognized Firm</div>
                <div className="text-white/70 text-xs">Delhi NCR 2023</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-20 bg-lighter">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-14">
            <span className="text-accent font-semibold text-sm tracking-wider uppercase">Our Core Values</span>
            <h2 className="text-3xl md:text-4xl font-bold text-primary mt-2 mb-4" style={{ fontFamily: 'Georgia, serif' }}>
              The Principles That Guide Us
            </h2>
            <p className="text-gray-500 max-w-2xl mx-auto">
              Our values are the foundation of everything we do — from how we handle cases to how we treat our clients and colleagues.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => (
              <div key={index} className="bg-white rounded-xl p-6 card-hover shadow-sm border border-gray-100">
                <div className="bg-accent/10 w-14 h-14 rounded-lg flex items-center justify-center mb-4">
                  <value.icon className="text-accent" size={26} />
                </div>
                <h3 className="text-lg font-bold text-primary mb-2">{value.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{value.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Vision & Mission */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-primary rounded-2xl p-10 text-white">
              <Eye className="text-accent mb-4" size={40} />
              <h3 className="text-2xl font-bold mb-4" style={{ fontFamily: 'Georgia, serif' }}>Our Vision</h3>
              <p className="text-gray-300 leading-relaxed mb-6">
                To be the most trusted and sought-after law firm in India, recognized for our unwavering commitment to justice, our innovative legal strategies, and our positive impact on the communities we serve.
              </p>
              <ul className="space-y-3">
                {['Leading legal innovation in India', 'Setting benchmarks in client satisfaction', 'Expanding access to justice for all'].map((item) => (
                  <li key={item} className="flex items-center gap-2 text-gray-300 text-sm">
                    <CheckCircle className="text-accent shrink-0" size={16} />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-accent rounded-2xl p-10 text-white">
              <Target className="text-white mb-4" size={40} />
              <h3 className="text-2xl font-bold mb-4" style={{ fontFamily: 'Georgia, serif' }}>Our Mission</h3>
              <p className="text-white/80 leading-relaxed mb-6">
                To deliver outstanding legal solutions through a combination of deep expertise, strategic thinking, and personalized service. We strive to make quality legal representation accessible and affordable.
              </p>
              <ul className="space-y-3">
                {['Client-centered legal solutions', 'Transparent and ethical practice', 'Continuous learning and adaptation'].map((item) => (
                  <li key={item} className="flex items-center gap-2 text-white/80 text-sm">
                    <CheckCircle className="text-white shrink-0" size={16} />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Our Team */}
      <section className="py-20 bg-lighter">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-14">
            <span className="text-accent font-semibold text-sm tracking-wider uppercase">Our Team</span>
            <h2 className="text-3xl md:text-4xl font-bold text-primary mt-2 mb-4" style={{ fontFamily: 'Georgia, serif' }}>
              Meet Our Legal Experts
            </h2>
            <p className="text-gray-500 max-w-2xl mx-auto">
              Our team comprises some of the most talented and experienced legal professionals in the country, each bringing unique expertise to serve our clients.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {team.map((member, index) => (
              <div key={index} className="bg-white rounded-xl overflow-hidden card-hover shadow-sm border border-gray-100">
                <div className="bg-primary p-6 text-center">
                  <div className="w-20 h-20 bg-accent rounded-full flex items-center justify-center mx-auto mb-4 text-white text-2xl font-bold" style={{ fontFamily: 'Georgia, serif' }}>
                    {member.name.split(' ').slice(-1)[0].charAt(0)}
                  </div>
                </div>
                <div className="p-6 text-center">
                  <h3 className="text-lg font-bold text-primary mb-1">{member.name}</h3>
                  <p className="text-accent text-sm font-medium mb-2">{member.role}</p>
                  <p className="text-gray-500 text-sm mb-1">{member.specialization}</p>
                  <p className="text-gray-400 text-xs">{member.experience}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Milestones */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-14">
            <span className="text-accent font-semibold text-sm tracking-wider uppercase">Our Journey</span>
            <h2 className="text-3xl md:text-4xl font-bold text-primary mt-2 mb-4" style={{ fontFamily: 'Georgia, serif' }}>
              Milestones & Achievements
            </h2>
          </div>
          <div className="max-w-3xl mx-auto">
            {milestones.map((milestone, index) => (
              <div key={index} className="flex gap-6 mb-8 last:mb-0">
                <div className="flex flex-col items-center">
                  <div className="bg-accent text-white font-bold text-sm px-4 py-2 rounded-full">
                    {milestone.year}
                  </div>
                  {index < milestones.length - 1 && (
                    <div className="w-0.5 h-full bg-accent/30 mt-2"></div>
                  )}
                </div>
                <div className="bg-lighter rounded-xl p-6 flex-1 card-hover border border-gray-100">
                  <p className="text-gray-700 font-medium">{milestone.event}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-accent">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4" style={{ fontFamily: 'Georgia, serif' }}>
            Ready to Work with Us?
          </h2>
          <p className="text-white/80 max-w-2xl mx-auto mb-8">
            Join our growing list of satisfied clients. Let our experience work for you.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 bg-primary hover:bg-primary-light text-white px-8 py-3.5 rounded-md font-semibold transition-all duration-300 shadow-lg"
          >
            Contact Us Today
            <ArrowRight size={18} />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default About;
