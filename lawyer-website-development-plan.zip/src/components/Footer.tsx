import { Link } from 'react-router-dom';
import { Scale, MapPin, Phone, Mail, Clock, ArrowRight, Globe, Users, MessageCircle, Briefcase } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-primary text-white">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* About */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-accent rounded-full p-2">
                <Scale className="text-primary" size={24} />
              </div>
              <div>
                <h3 className="text-xl font-bold" style={{ fontFamily: 'Georgia, serif' }}>Legal Edge</h3>
                <p className="text-xs text-gray-400 tracking-widest uppercase">Associates</p>
              </div>
            </div>
            <p className="text-gray-300 text-sm leading-relaxed mb-6">
              With over 5 years of experience in legal practice, we provide comprehensive legal solutions with a client-first approach. Our team of expert lawyers ensures the best outcomes for every case.
            </p>
            <div className="flex gap-3">
              <a href="#" className="bg-primary-light hover:bg-accent p-2.5 rounded-full transition-all duration-300">
                <Globe size={18} />
              </a>
              <a href="#" className="bg-primary-light hover:bg-accent p-2.5 rounded-full transition-all duration-300">
                <Users size={18} />
              </a>
              <a href="#" className="bg-primary-light hover:bg-accent p-2.5 rounded-full transition-all duration-300">
                <MessageCircle size={18} />
              </a>
              <a href="#" className="bg-primary-light hover:bg-accent p-2.5 rounded-full transition-all duration-300">
                <Briefcase size={18} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-6 relative">
              Quick Links
              <span className="absolute bottom-0 left-0 w-12 h-0.5 bg-accent -mb-2"></span>
            </h3>
            <ul className="space-y-3 mt-4">
              {[
                { name: 'Home', path: '/' },
                { name: 'About Us', path: '/about' },
                { name: 'Our Expertise', path: '/our-expertise' },
                { name: 'Our Services', path: '/our-services' },
                { name: 'Blog', path: '/blog' },
                { name: 'Contact Us', path: '/contact' },
              ].map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-gray-300 hover:text-accent text-sm flex items-center gap-2 transition-all duration-300 group"
                  >
                    <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Our Expertise */}
          <div>
            <h3 className="text-lg font-bold mb-6 relative">
              Our Expertise
              <span className="absolute bottom-0 left-0 w-12 h-0.5 bg-accent -mb-2"></span>
            </h3>
            <ul className="space-y-3 mt-4">
              {['Divorce Lawyer', 'Criminal Lawyer', 'Civil Lawyer', 'Matrimonial Lawyer', 'Corporate Lawyer', 'Supreme Court Lawyer'].map((item) => (
                <li key={item}>
                  <Link
                    to="/our-expertise"
                    className="text-gray-300 hover:text-accent text-sm flex items-center gap-2 transition-all duration-300 group"
                  >
                    <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-bold mb-6 relative">
              Contact Info
              <span className="absolute bottom-0 left-0 w-12 h-0.5 bg-accent -mb-2"></span>
            </h3>
            <ul className="space-y-4 mt-4">
              <li className="flex items-start gap-3">
                <MapPin size={18} className="text-accent mt-0.5 shrink-0" />
                <span className="text-gray-300 text-sm">123 Legal Chambers, Connaught Place, New Delhi - 110001</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone size={18} className="text-accent shrink-0" />
                <span className="text-gray-300 text-sm">+91 98765 43210</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail size={18} className="text-accent shrink-0" />
                <span className="text-gray-300 text-sm">info@legaledgeassociates.com</span>
              </li>
              <li className="flex items-start gap-3">
                <Clock size={18} className="text-accent mt-0.5 shrink-0" />
                <span className="text-gray-300 text-sm">Mon - Sat: 10:00 AM - 7:00 PM</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-700">
        <div className="max-w-7xl mx-auto px-4 py-6 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-400 text-sm">
            © 2024 Legal Edge Associates. All Rights Reserved.
          </p>
          <div className="flex gap-6 text-sm text-gray-400">
            <a href="#" className="hover:text-accent transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-accent transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-accent transition-colors">Disclaimer</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
