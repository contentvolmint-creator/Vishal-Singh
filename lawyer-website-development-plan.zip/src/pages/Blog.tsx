import { Link } from 'react-router-dom';
import { Scale, BookOpen, Calendar, Clock, ArrowRight, ChevronRight, Tag, Search } from 'lucide-react';
import { useState } from 'react';

const categories = ['All', 'Family Law', 'Criminal Law', 'Property Law', 'Corporate Law', 'Cyber Law', 'Legal Tips', 'News'];

const blogPosts = [
  {
    id: 1,
    title: 'New Amendments in Family Law 2024: What You Need to Know',
    excerpt: 'The government has introduced significant amendments to family law provisions affecting divorce proceedings, child custody arrangements, and maintenance calculations. Here\'s a comprehensive breakdown of what has changed and how it affects you.',
    category: 'Family Law',
    date: 'Dec 15, 2024',
    readTime: '8 min read',
    featured: true,
    content: 'The recent amendments to family law bring substantial changes to how courts handle divorce and custody cases. Key changes include simplified mutual consent divorce procedures, new guidelines for calculating maintenance, and enhanced protections for children in custody disputes. Understanding these changes is crucial for anyone currently involved in or considering family law proceedings.',
  },
  {
    id: 2,
    title: '5 Things to Know Before Filing a Property Dispute',
    excerpt: 'Property disputes can be complex and time-consuming. Understanding these key aspects before filing can save you significant time, money, and emotional stress. From title verification to limitation periods, here\'s what you must know.',
    category: 'Property Law',
    date: 'Dec 10, 2024',
    readTime: '6 min read',
    featured: true,
    content: 'Before initiating a property dispute, it\'s essential to verify the title, understand the limitation period, gather all relevant documents, consider alternative dispute resolution, and assess the financial implications. A well-prepared case significantly increases your chances of a favorable outcome.',
  },
  {
    id: 3,
    title: 'Supreme Court Landmark Judgment on Cyber Law',
    excerpt: 'The Supreme Court delivered a groundbreaking judgment that strengthens the legal framework for cyber crime victims and establishes new standards for digital privacy rights in India.',
    category: 'Cyber Law',
    date: 'Dec 05, 2024',
    readTime: '7 min read',
    featured: true,
    content: 'In a landmark ruling, the Supreme Court has expanded the scope of digital privacy rights and established stricter guidelines for law enforcement agencies handling cyber crime cases. This judgment sets a new precedent for how cyber crimes are investigated and prosecuted in India.',
  },
  {
    id: 4,
    title: 'Understanding Your Rights in a Criminal Case',
    excerpt: 'Being accused of a crime can be overwhelming. Knowing your fundamental rights during investigation and trial is essential for ensuring fair treatment under the law.',
    category: 'Criminal Law',
    date: 'Nov 28, 2024',
    readTime: '5 min read',
    featured: false,
    content: 'Every accused person has fundamental rights including the right to silence, the right to legal representation, the right to bail in bailable offences, the right to a fair trial, and protection against self-incrimination. Understanding these rights can make a crucial difference in how your case unfolds.',
  },
  {
    id: 5,
    title: 'RERA and Homebuyers: A Complete Guide',
    excerpt: 'The Real Estate Regulation Act has empowered homebuyers significantly. Learn how to file a RERA complaint and what remedies are available to you.',
    category: 'Property Law',
    date: 'Nov 20, 2024',
    readTime: '9 min read',
    featured: false,
    content: 'RERA provides homebuyers with powerful legal tools to address grievances against builders. From project delays to construction defects, understanding how to navigate the RERA complaint process can help you protect your investment and seek appropriate compensation.',
  },
  {
    id: 6,
    title: 'Legal Documentation: Common Mistakes to Avoid',
    excerpt: 'Poorly drafted legal documents can lead to disputes and financial losses. Here are the most common mistakes people make and how to avoid them.',
    category: 'Legal Tips',
    date: 'Nov 15, 2024',
    readTime: '4 min read',
    featured: false,
    content: 'Common documentation mistakes include vague terms, missing essential clauses, not registering documents, failing to verify identities, and not including dispute resolution mechanisms. Having a legal professional review your documents can prevent costly disputes later.',
  },
  {
    id: 7,
    title: 'Corporate Compliance Updates for 2024',
    excerpt: 'Stay updated with the latest regulatory changes affecting businesses in India. From GST amendments to company law updates, here\'s what you need to know.',
    category: 'Corporate Law',
    date: 'Nov 10, 2024',
    readTime: '7 min read',
    featured: false,
    content: 'The regulatory landscape for businesses continues to evolve. Key updates for 2024 include changes in GST filing requirements, new company law provisions, updated compliance deadlines, and enhanced disclosure requirements. Businesses must stay proactive to maintain compliance.',
  },
  {
    id: 8,
    title: 'Child Custody: Best Interests of the Child Standard',
    excerpt: 'Indian courts prioritize the welfare of the child in custody decisions. Understanding how this standard is applied can help you prepare a stronger case.',
    category: 'Family Law',
    date: 'Nov 05, 2024',
    readTime: '6 min read',
    featured: false,
    content: 'The "best interests of the child" standard considers multiple factors including the child\'s age, emotional bonds with parents, each parent\'s ability to provide care, the child\'s educational needs, and any history of abuse or neglect. Courts focus on what arrangement best serves the child\'s overall welfare.',
  },
  {
    id: 9,
    title: 'How to File a Consumer Complaint: Step-by-Step Guide',
    excerpt: 'Consumer disputes are common, but many people don\'t know how to seek legal remedy. This guide walks you through the entire process.',
    category: 'Legal Tips',
    date: 'Oct 28, 2024',
    readTime: '5 min read',
    featured: false,
    content: 'Filing a consumer complaint involves identifying the right forum, gathering evidence, drafting the complaint, paying the requisite fee, and attending hearings. The Consumer Protection Act 2019 has made the process more accessible with e-filing options and simplified procedures.',
  },
];

const Blog = () => {
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredPosts = blogPosts.filter((post) => {
    const matchesCategory = activeCategory === 'All' || post.category === activeCategory;
    const matchesSearch = post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const featuredPosts = blogPosts.filter((post) => post.featured);

  return (
    <div>
      {/* Hero */}
      <section className="hero-gradient py-20 md:py-28">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="inline-flex items-center gap-2 bg-accent/20 text-accent px-4 py-2 rounded-full text-sm font-medium mb-6">
            <BookOpen size={16} />
            Blog & Legal Updates
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4" style={{ fontFamily: 'Georgia, serif' }}>
            Legal Insights & Updates
          </h1>
          <p className="text-gray-300 max-w-2xl mx-auto text-lg">
            Stay informed with the latest legal developments, expert analysis, and practical tips from our experienced legal team.
          </p>
        </div>
      </section>

      {/* Featured Posts */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-2xl font-bold text-primary mb-8" style={{ fontFamily: 'Georgia, serif' }}>
            Featured Articles
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            {featuredPosts.map((post) => (
              <div key={post.id} className="bg-lighter rounded-xl overflow-hidden card-hover border border-gray-100 group">
                <div className="bg-primary p-6 relative">
                  <div className="absolute top-4 right-4 bg-accent text-white text-xs font-bold px-3 py-1 rounded-full">
                    {post.category}
                  </div>
                  <Scale className="text-accent/30" size={48} />
                </div>
                <div className="p-6">
                  <div className="flex items-center gap-4 text-xs text-gray-400 mb-3">
                    <span className="flex items-center gap-1">
                      <Calendar size={12} />
                      {post.date}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock size={12} />
                      {post.readTime}
                    </span>
                  </div>
                  <h3 className="text-lg font-bold text-primary mb-3 group-hover:text-accent transition-colors leading-tight">
                    {post.title}
                  </h3>
                  <p className="text-gray-500 text-sm leading-relaxed mb-4">{post.excerpt.slice(0, 120)}...</p>
                  <button className="text-accent font-semibold text-sm flex items-center gap-1 hover:gap-2 transition-all">
                    Read More <ArrowRight size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* All Posts with Filter */}
      <section className="py-16 bg-lighter">
        <div className="max-w-7xl mx-auto px-4">
          {/* Search & Filter */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-10">
            <div>
              <h2 className="text-2xl font-bold text-primary" style={{ fontFamily: 'Georgia, serif' }}>
                All Articles
              </h2>
              <p className="text-gray-500 text-sm mt-1">{filteredPosts.length} articles found</p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                <input
                  type="text"
                  placeholder="Search articles..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-4 py-2.5 rounded-md border border-gray-200 focus:border-accent focus:outline-none text-sm w-full sm:w-64"
                />
              </div>
            </div>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap gap-2 mb-8">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                  activeCategory === cat
                    ? 'bg-primary text-white'
                    : 'bg-white text-gray-600 hover:bg-primary hover:text-white border border-gray-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Blog Posts Grid */}
          <div className="space-y-6">
            {filteredPosts.map((post) => (
              <div key={post.id} className="bg-white rounded-xl overflow-hidden card-hover border border-gray-100 group">
                <div className="flex flex-col md:flex-row">
                  <div className="bg-primary p-8 md:w-48 flex flex-col items-center justify-center shrink-0">
                    <Scale className="text-accent/50" size={36} />
                    <div className="mt-2 bg-accent text-white text-xs font-bold px-3 py-1 rounded-full">
                      {post.category}
                    </div>
                  </div>
                  <div className="p-6 flex-1">
                    <div className="flex items-center gap-4 text-xs text-gray-400 mb-2">
                      <span className="flex items-center gap-1">
                        <Calendar size={12} />
                        {post.date}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock size={12} />
                        {post.readTime}
                      </span>
                      <span className="flex items-center gap-1">
                        <Tag size={12} />
                        {post.category}
                      </span>
                    </div>
                    <h3 className="text-xl font-bold text-primary mb-2 group-hover:text-accent transition-colors">
                      {post.title}
                    </h3>
                    <p className="text-gray-500 text-sm leading-relaxed mb-3">{post.excerpt}</p>
                    <button className="text-accent font-semibold text-sm flex items-center gap-1 hover:gap-2 transition-all">
                      Read Full Article <ChevronRight size={14} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredPosts.length === 0 && (
            <div className="text-center py-16">
              <BookOpen className="text-gray-300 mx-auto mb-4" size={48} />
              <h3 className="text-gray-400 text-lg font-medium">No articles found</h3>
              <p className="text-gray-400 text-sm mt-2">Try adjusting your search or filter criteria.</p>
            </div>
          )}
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-16 bg-primary">
        <div className="max-w-7xl mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <BookOpen className="text-accent mx-auto mb-4" size={40} />
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-4" style={{ fontFamily: 'Georgia, serif' }}>
              Subscribe to Legal Updates
            </h2>
            <p className="text-gray-300 mb-8">
              Get the latest legal insights, tips, and updates delivered directly to your inbox. No spam, just valuable legal information.
            </p>
            <form className="flex flex-col sm:flex-row gap-3" onSubmit={(e) => e.preventDefault()}>
              <input
                type="email"
                placeholder="Enter your email address"
                className="flex-1 px-4 py-3 rounded-md border border-gray-600 bg-white/10 text-white placeholder-gray-400 focus:border-accent focus:outline-none text-sm"
              />
              <button
                type="submit"
                className="bg-accent hover:bg-accent-light text-white px-8 py-3 rounded-md font-semibold transition-all duration-300"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-accent">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-4" style={{ fontFamily: 'Georgia, serif' }}>
            Need Legal Advice on Any of These Topics?
          </h2>
          <p className="text-white/80 max-w-2xl mx-auto mb-8">
            Our expert lawyers can provide personalized guidance on any legal matter discussed in our articles.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 bg-primary hover:bg-primary-light text-white px-8 py-3.5 rounded-md font-semibold transition-all duration-300 shadow-lg"
          >
            Contact Us for Legal Help
            <ArrowRight size={18} />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Blog;
