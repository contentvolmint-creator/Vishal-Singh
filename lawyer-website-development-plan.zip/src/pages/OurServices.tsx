import { Link } from 'react-router-dom';
import {
  Scale, Shield, Baby, FileText, Building, Home,
  Landmark, Gavel, ShoppingBag, Monitor, Heart,
  ArrowRight, CheckCircle, ChevronRight, Users, Briefcase
} from 'lucide-react';

const services = [
  {
    icon: Baby,
    title: 'Child Custody Lawyer',
    shortDesc: 'Protecting the best interests of your children.',
    fullDesc: 'Child custody disputes are among the most sensitive and emotionally charged legal matters. Our child custody lawyers understand that your children\'s welfare is paramount. We handle all types of custody cases including physical custody, legal custody, visitation rights, and custody modifications with compassion and legal rigor.',
    keyPoints: ['Physical & Legal Custody', 'Visitation Rights', 'Custody Modification', 'Guardianship Petitions', 'Inter-State Custody', 'International Custody (Hague Convention)'],
  },
  {
    icon: FileText,
    title: 'Legal Documentation',
    shortDesc: 'Precise and legally sound documentation services.',
    fullDesc: 'Proper legal documentation is the foundation of any successful legal strategy. Our legal documentation services cover drafting, reviewing, and vetting of all types of legal documents including contracts, agreements, deeds, wills, power of attorney, and more. We ensure every document is legally compliant and protects your interests.',
    keyPoints: ['Contract Drafting & Review', 'Agreement Preparation', 'Will & Testament', 'Power of Attorney', 'Affidavits & Declarations', 'Legal Notices'],
  },
  {
    icon: Building,
    title: 'Debt Recovery Tribunal Lawyer',
    shortDesc: 'Expert representation before DRT and DRAT.',
    fullDesc: 'Debt Recovery Tribunal (DRT) matters require specialized knowledge of banking and financial laws. Our DRT lawyers represent both borrowers and financial institutions before the Debt Recovery Tribunal and Debt Recovery Appellate Tribunal (DRAT), handling cases related to loan recovery, NPA classification, and SARFAESI Act proceedings.',
    keyPoints: ['DRT Original Applications', 'DRAT Appeals', 'SARFAESI Act Matters', 'Securitization Cases', 'Bank Loan Disputes', 'NPA Classification Challenges'],
  },
  {
    icon: Home,
    title: 'Property Lawyer',
    shortDesc: 'Comprehensive property legal services and dispute resolution.',
    fullDesc: 'Property transactions and disputes require meticulous attention to detail and deep knowledge of property laws. Our property lawyers handle property registration, title verification, property disputes, land acquisition matters, and real estate transactions. We ensure your property investments are legally secure.',
    keyPoints: ['Property Registration', 'Title Verification', 'Property Disputes', 'Land Acquisition', 'Sale & Purchase Agreements', 'Lease & Rental Agreements'],
  },
  {
    icon: Landmark,
    title: 'Delhi High Court Lawyer',
    shortDesc: 'Skilled representation before the Delhi High Court.',
    fullDesc: 'The Delhi High Court handles some of the most significant and complex legal matters in the capital. Our Delhi High Court lawyers have extensive experience in filing and arguing writ petitions, appeals, revisions, and other proceedings before the High Court. We provide strategic representation in both civil and criminal matters.',
    keyPoints: ['Writ Petitions', 'Civil Appeals', 'Criminal Appeals', 'Revision Petitions', 'Company Petitions', 'Public Interest Litigation'],
  },
  {
    icon: Shield,
    title: 'C.A.T Services Matters Lawyer',
    shortDesc: 'Expert handling of Central Administrative Tribunal cases.',
    fullDesc: 'Central Administrative Tribunal (CAT) handles disputes and complaints regarding recruitment and conditions of service of government employees. Our CAT lawyers specialize in representing government servants in service matters including promotion disputes, disciplinary proceedings, pension issues, and transfer challenges.',
    keyPoints: ['Service Disputes', 'Promotion Matters', 'Disciplinary Proceedings', 'Pension & Retirement Issues', 'Transfer Challenges', 'OA & TA Filing'],
  },
  {
    icon: Gavel,
    title: 'RERA Matters',
    shortDesc: 'Protecting homebuyers\' rights under RERA.',
    fullDesc: 'The Real Estate (Regulation and Development) Act, 2016 (RERA) has transformed the real estate landscape in India. Our RERA lawyers help homebuyers file complaints against builders for project delays, construction defects, and unfair practices. We also assist builders in RERA compliance and registration.',
    keyPoints: ['Homebuyer Complaints', 'Project Delay Claims', 'Construction Defects', 'Builder Compliance', 'RERA Registration', 'Compensation Claims'],
  },
  {
    icon: ShoppingBag,
    title: 'Consumer Disputes Lawyer',
    shortDesc: 'Fighting for consumer rights and fair compensation.',
    fullDesc: 'Consumer disputes can arise from defective products, deficient services, or unfair trade practices. Our consumer disputes lawyers represent clients before Consumer Disputes Redressal Commissions at district, state, and national levels. We help you seek appropriate compensation and resolution for consumer grievances.',
    keyPoints: ['Consumer Complaints', 'Defective Product Claims', 'Service Deficiency', 'Unfair Trade Practices', 'E-Commerce Disputes', 'Compensation Claims'],
  },
  {
    icon: Monitor,
    title: 'Cyber Law Cases Lawyer',
    shortDesc: 'Expert handling of cyber crime and digital law matters.',
    fullDesc: 'As digital interactions grow, so do cyber crimes and digital legal issues. Our cyber law lawyers handle cases involving online fraud, identity theft, data privacy violations, cyber stalking, and social media offences. We also advise businesses on IT Act compliance and data protection strategies.',
    keyPoints: ['Cyber Crime Complaints', 'Online Fraud Cases', 'Data Privacy Issues', 'Identity Theft', 'Social Media Offences', 'IT Act Compliance'],
  },
  {
    icon: Heart,
    title: 'Court Marriage Registration',
    shortDesc: 'Seamless court marriage and registration services.',
    fullDesc: 'Court marriage provides a legal and straightforward way to get married under the Special Marriage Act or other personal laws. Our court marriage lawyers guide you through the entire process — from application filing to notice period compliance to the final marriage registration — ensuring a smooth and hassle-free experience.',
    keyPoints: ['Special Marriage Act', 'Hindu Marriage Act', 'Inter-Caste Marriage', 'Inter-Religion Marriage', 'NRI Marriage', 'Marriage Certificate'],
  },
];

const process = [
  { step: '01', title: 'Consultation', desc: 'Share your legal issue with us through a free initial consultation.' },
  { step: '02', title: 'Case Analysis', desc: 'Our experts analyze your case and develop a strategic legal plan.' },
  { step: '03', title: 'Documentation', desc: 'We prepare all necessary legal documents and filings.' },
  { step: '04', title: 'Representation', desc: 'We represent you vigorously in court or negotiations.' },
  { step: '05', title: 'Resolution', desc: 'We work tirelessly until your case is favorably resolved.' },
];

const OurServices = () => {
  return (
    <div>
      {/* Hero */}
      <section className="hero-gradient py-20 md:py-28">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="inline-flex items-center gap-2 bg-accent/20 text-accent px-4 py-2 rounded-full text-sm font-medium mb-6">
            <Briefcase size={16} />
            Our Services
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4" style={{ fontFamily: 'Georgia, serif' }}>
            Legal Services We Offer
          </h1>
          <p className="text-gray-300 max-w-2xl mx-auto text-lg">
            From child custody to cyber law, we offer a comprehensive range of legal services designed to address your specific needs.
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <div
                key={index}
                className="bg-lighter rounded-2xl overflow-hidden card-hover border border-gray-100"
              >
                <div className="p-8">
                  <div className="flex items-start gap-4 mb-4">
                    <div className="bg-primary w-14 h-14 rounded-lg flex items-center justify-center shrink-0">
                      <service.icon className="text-accent" size={26} />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-primary mb-1" style={{ fontFamily: 'Georgia, serif' }}>
                        {service.title}
                      </h3>
                      <p className="text-accent text-sm font-medium">{service.shortDesc}</p>
                    </div>
                  </div>
                  <p className="text-gray-600 text-sm leading-relaxed mb-5">{service.fullDesc}</p>
                  <div className="grid grid-cols-2 gap-2 mb-5">
                    {service.keyPoints.map((point, i) => (
                      <div key={i} className="flex items-center gap-2 text-xs text-gray-600">
                        <CheckCircle className="text-accent shrink-0" size={14} />
                        <span>{point}</span>
                      </div>
                    ))}
                  </div>
                  <Link
                    to="/contact"
                    className="inline-flex items-center gap-2 bg-accent hover:bg-accent-light text-white px-5 py-2.5 rounded-md font-semibold transition-all duration-300 text-sm"
                  >
                    Get Legal Help
                    <ChevronRight size={16} />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Process */}
      <section className="py-20 bg-primary">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-14">
            <span className="text-accent font-semibold text-sm tracking-wider uppercase">How We Work</span>
            <h2 className="text-3xl md:text-4xl font-bold text-white mt-2 mb-4" style={{ fontFamily: 'Georgia, serif' }}>
              Our Legal Process
            </h2>
            <p className="text-gray-300 max-w-2xl mx-auto">
              We follow a structured and transparent approach to ensure the best possible outcome for your case.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
            {process.map((step, index) => (
              <div key={index} className="text-center">
                <div className="bg-accent/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 border-2 border-accent">
                  <span className="text-accent font-bold text-lg">{step.step}</span>
                </div>
                <h3 className="text-white font-bold mb-2">{step.title}</h3>
                <p className="text-gray-400 text-xs leading-relaxed">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Service Comparison */}
      <section className="py-20 bg-lighter">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-14">
            <span className="text-accent font-semibold text-sm tracking-wider uppercase">Our Commitment</span>
            <h2 className="text-3xl md:text-4xl font-bold text-primary mt-2 mb-4" style={{ fontFamily: 'Georgia, serif' }}>
              Why Clients Trust Our Services
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white rounded-xl p-8 text-center card-hover shadow-sm border border-gray-100">
              <div className="bg-green-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Scale className="text-green-600" size={30} />
              </div>
              <h3 className="text-lg font-bold text-primary mb-3">Transparent Pricing</h3>
              <p className="text-gray-500 text-sm leading-relaxed">
                We provide clear, upfront pricing with no hidden costs. You know exactly what you're paying for before we begin.
              </p>
            </div>
            <div className="bg-white rounded-xl p-8 text-center card-hover shadow-sm border border-gray-100">
              <div className="bg-blue-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="text-blue-600" size={30} />
              </div>
              <h3 className="text-lg font-bold text-primary mb-3">Dedicated Team</h3>
              <p className="text-gray-500 text-sm leading-relaxed">
                Each case is assigned a dedicated team of lawyers who focus exclusively on achieving the best results for you.
              </p>
            </div>
            <div className="bg-white rounded-xl p-8 text-center card-hover shadow-sm border border-gray-100">
              <div className="bg-purple-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileText className="text-purple-600" size={30} />
              </div>
              <h3 className="text-lg font-bold text-primary mb-3">Regular Updates</h3>
              <p className="text-gray-500 text-sm leading-relaxed">
                Stay informed with regular case updates. We believe in transparent communication and keep you involved at every step.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-accent">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4" style={{ fontFamily: 'Georgia, serif' }}>
            Let Us Handle Your Legal Matter
          </h2>
          <p className="text-white/80 max-w-2xl mx-auto mb-8">
            Don't navigate the legal system alone. Our experienced team is ready to fight for your rights.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link
              to="/contact"
              className="bg-primary hover:bg-primary-light text-white px-8 py-3.5 rounded-md font-semibold transition-all duration-300 shadow-lg flex items-center gap-2"
            >
              Book Free Consultation
              <ArrowRight size={18} />
            </Link>
            <Link
              to="/our-expertise"
              className="border-2 border-white/30 hover:border-primary text-white hover:text-primary px-8 py-3.5 rounded-md font-semibold transition-all duration-300"
            >
              View Our Expertise
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default OurServices;
