import { useState } from 'react';
import {
  MapPin, Phone, Mail, Clock, Send,
  CheckCircle, MessageCircle, Shield
} from 'lucide-react';

const contactInfo = [
  {
    icon: MapPin,
    title: 'Our Office',
    lines: ['123 Legal Chambers, Connaught Place', 'New Delhi - 110001, India'],
  },
  {
    icon: Phone,
    title: 'Phone Numbers',
    lines: ['+91 98765 43210', '+91 11 2345 6789'],
  },
  {
    icon: Mail,
    title: 'Email Address',
    lines: ['info@legaledgeassociates.com', 'consultations@legaledgeassociates.com'],
  },
  {
    icon: Clock,
    title: 'Office Hours',
    lines: ['Mon - Sat: 10:00 AM - 7:00 PM', 'Sunday: By Appointment Only'],
  },
];

const Contact = () => {
  const [formSubmitted, setFormSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitted(true);
    setTimeout(() => setFormSubmitted(false), 5000);
  };

  return (
    <div>
      {/* Hero */}
      <section className="hero-gradient py-20 md:py-28">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="inline-flex items-center gap-2 bg-accent/20 text-accent px-4 py-2 rounded-full text-sm font-medium mb-6">
            <MessageCircle size={16} />
            Contact Us
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4" style={{ fontFamily: 'Georgia, serif' }}>
            Get In Touch With Us
          </h1>
          <p className="text-gray-300 max-w-2xl mx-auto text-lg">
            Have a legal question or need representation? We're here to help. Reach out to us for a free initial consultation.
          </p>
        </div>
      </section>

      {/* Contact Info Cards */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {contactInfo.map((info, index) => (
              <div key={index} className="bg-lighter rounded-xl p-6 text-center card-hover border border-gray-100">
                <div className="bg-accent/10 w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4">
                  <info.icon className="text-accent" size={24} />
                </div>
                <h3 className="text-primary font-bold mb-3">{info.title}</h3>
                {info.lines.map((line, i) => (
                  <p key={i} className="text-gray-500 text-sm">{line}</p>
                ))}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form & Map */}
      <section className="py-16 bg-lighter">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12">
            {/* Form */}
            <div>
              <span className="text-accent font-semibold text-sm tracking-wider uppercase">Send Us a Message</span>
              <h2 className="text-3xl font-bold text-primary mt-2 mb-6" style={{ fontFamily: 'Georgia, serif' }}>
                Book Your Free Consultation
              </h2>
              <p className="text-gray-600 mb-8">
                Fill out the form below and our team will get back to you within 24 hours. Your first consultation is completely free.
              </p>

              {formSubmitted ? (
                <div className="bg-green-50 border border-green-200 rounded-xl p-8 text-center">
                  <CheckCircle className="text-green-500 mx-auto mb-4" size={48} />
                  <h3 className="text-green-800 text-xl font-bold mb-2">Message Sent Successfully!</h3>
                  <p className="text-green-600 text-sm">
                    Thank you for reaching out. Our team will contact you within 24 hours to discuss your legal matter.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-gray-700 text-sm font-medium mb-1 block">First Name *</label>
                      <input
                        type="text"
                        required
                        placeholder="Enter first name"
                        className="w-full px-4 py-3 rounded-md border border-gray-200 focus:border-accent focus:outline-none text-sm transition-colors"
                      />
                    </div>
                    <div>
                      <label className="text-gray-700 text-sm font-medium mb-1 block">Last Name *</label>
                      <input
                        type="text"
                        required
                        placeholder="Enter last name"
                        className="w-full px-4 py-3 rounded-md border border-gray-200 focus:border-accent focus:outline-none text-sm transition-colors"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-gray-700 text-sm font-medium mb-1 block">Email Address *</label>
                      <input
                        type="email"
                        required
                        placeholder="Enter email"
                        className="w-full px-4 py-3 rounded-md border border-gray-200 focus:border-accent focus:outline-none text-sm transition-colors"
                      />
                    </div>
                    <div>
                      <label className="text-gray-700 text-sm font-medium mb-1 block">Phone Number *</label>
                      <input
                        type="tel"
                        required
                        placeholder="Enter phone number"
                        className="w-full px-4 py-3 rounded-md border border-gray-200 focus:border-accent focus:outline-none text-sm transition-colors"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-gray-700 text-sm font-medium mb-1 block">Legal Area *</label>
                    <select
                      required
                      className="w-full px-4 py-3 rounded-md border border-gray-200 focus:border-accent focus:outline-none text-sm text-gray-500 transition-colors"
                    >
                      <option value="">Select a legal area</option>
                      <option>Divorce Lawyer</option>
                      <option>Domestic Violence Lawyer</option>
                      <option>Matrimonial Lawyer</option>
                      <option>Family Disputes Lawyer</option>
                      <option>Bail Matters Lawyer</option>
                      <option>Cheque Bounce Lawyer</option>
                      <option>Civil Lawyer</option>
                      <option>Criminal Lawyer</option>
                      <option>Supreme Court Lawyer</option>
                      <option>Corporate Lawyer</option>
                      <option>Child Custody Lawyer</option>
                      <option>Legal Documentation</option>
                      <option>Debt Recovery Tribunal Lawyer</option>
                      <option>Property Lawyer</option>
                      <option>Delhi High Court Lawyer</option>
                      <option>C.A.T Services Matters Lawyer</option>
                      <option>RERA Matters</option>
                      <option>Consumer Disputes Lawyer</option>
                      <option>Cyber Law Cases Lawyer</option>
                      <option>Court Marriage Registration</option>
                      <option>Other</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-gray-700 text-sm font-medium mb-1 block">Preferred Consultation Time</label>
                    <select className="w-full px-4 py-3 rounded-md border border-gray-200 focus:border-accent focus:outline-none text-sm text-gray-500 transition-colors">
                      <option value="">Select preferred time</option>
                      <option>Morning (10 AM - 12 PM)</option>
                      <option>Afternoon (12 PM - 3 PM)</option>
                      <option>Evening (3 PM - 5 PM)</option>
                      <option>Late Evening (5 PM - 7 PM)</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-gray-700 text-sm font-medium mb-1 block">Case Description *</label>
                    <textarea
                      required
                      rows={5}
                      placeholder="Please provide a brief description of your legal matter..."
                      className="w-full px-4 py-3 rounded-md border border-gray-200 focus:border-accent focus:outline-none text-sm transition-colors resize-none"
                    ></textarea>
                  </div>
                  <div className="flex items-start gap-2">
                    <input type="checkbox" required className="mt-1 accent-accent" />
                    <label className="text-gray-500 text-xs">
                      I agree to the privacy policy and consent to being contacted regarding my legal inquiry. *
                    </label>
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-accent hover:bg-accent-light text-white py-3.5 rounded-md font-semibold transition-all duration-300 shadow-md flex items-center justify-center gap-2"
                  >
                    <Send size={18} />
                    Send Message & Book Consultation
                  </button>
                </form>
              )}
            </div>

            {/* Map & Additional Info */}
            <div>
              <div className="bg-primary rounded-2xl p-8 mb-6">
                <h3 className="text-white text-xl font-bold mb-6" style={{ fontFamily: 'Georgia, serif' }}>
                  Our Location
                </h3>
                <div className="bg-primary-light rounded-xl p-6 text-center mb-6">
                  <MapPin className="text-accent mx-auto mb-3" size={40} />
                  <p className="text-white font-semibold mb-1">Legal Edge Associates</p>
                  <p className="text-gray-300 text-sm">123 Legal Chambers, Connaught Place</p>
                  <p className="text-gray-300 text-sm">New Delhi - 110001, India</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white/10 rounded-lg p-4 text-center">
                    <Phone className="text-accent mx-auto mb-2" size={20} />
                    <div className="text-white text-sm font-medium">Call Us</div>
                    <div className="text-gray-300 text-xs mt-1">+91 98765 43210</div>
                  </div>
                  <div className="bg-white/10 rounded-lg p-4 text-center">
                    <Mail className="text-accent mx-auto mb-2" size={20} />
                    <div className="text-white text-sm font-medium">Email Us</div>
                    <div className="text-gray-300 text-xs mt-1">info@legaledge.com</div>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100">
                <h3 className="text-primary text-xl font-bold mb-4" style={{ fontFamily: 'Georgia, serif' }}>
                  Why Choose Us?
                </h3>
                <ul className="space-y-3">
                  {[
                    'Free Initial Consultation',
                    'Experienced Team of 10+ Lawyers',
                    '95% Success Rate',
                    'Transparent & Affordable Pricing',
                    'Quick Response Within 24 Hours',
                    'Confidential & Secure',
                  ].map((item, i) => (
                    <li key={i} className="flex items-center gap-3 text-gray-600 text-sm">
                      <CheckCircle className="text-accent shrink-0" size={18} />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-12">
            <span className="text-accent font-semibold text-sm tracking-wider uppercase">FAQs</span>
            <h2 className="text-3xl font-bold text-primary mt-2 mb-4" style={{ fontFamily: 'Georgia, serif' }}>
              Frequently Asked Questions
            </h2>
          </div>
          <div className="space-y-4">
            {[
              {
                q: 'Is the first consultation really free?',
                a: 'Yes, your first consultation with our legal team is completely free of charge. We believe everyone deserves access to initial legal guidance regardless of their financial situation.',
              },
              {
                q: 'How quickly can I expect a response?',
                a: 'We typically respond to all inquiries within 24 hours. For urgent matters, you can call us directly for immediate assistance.',
              },
              {
                q: 'Do you handle cases outside Delhi?',
                a: 'While our primary practice is in Delhi, we handle cases across India through our network of associate lawyers. Contact us to discuss your specific needs.',
              },
              {
                q: 'What are your consultation fees after the first session?',
                a: 'Our fees vary depending on the nature and complexity of the case. We offer transparent pricing and will provide you with a clear fee structure before proceeding.',
              },
              {
                q: 'Can I consult with a lawyer online?',
                a: 'Yes, we offer online consultations via video call for clients who cannot visit our office. This service is available for both initial and follow-up consultations.',
              },
            ].map((faq, index) => (
              <div key={index} className="bg-lighter rounded-xl p-6 border border-gray-100">
                <h3 className="text-primary font-bold mb-2">{faq.q}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Emergency Contact */}
      <section className="py-16 bg-primary">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <Shield className="text-accent mx-auto mb-4" size={48} />
          <h2 className="text-3xl font-bold text-white mb-4" style={{ fontFamily: 'Georgia, serif' }}>
            Need Urgent Legal Help?
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto mb-8">
            If you're facing an urgent legal situation such as arrest, domestic violence, or need immediate bail, don't wait. Call our emergency helpline available 24/7.
          </p>
          <a
            href="tel:+919876543210"
            className="inline-flex items-center gap-2 bg-accent hover:bg-accent-light text-white px-8 py-4 rounded-md font-semibold transition-all duration-300 shadow-lg text-lg"
          >
            <Phone size={22} />
            Emergency: +91 98765 43210
          </a>
        </div>
      </section>
    </div>
  );
};

export default Contact;
