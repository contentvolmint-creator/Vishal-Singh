import { Link } from 'react-router-dom';
import {
  Scale, Shield, Heart, Users, Lock, FileText, Gavel,
  Building, ArrowRight, CheckCircle, ChevronRight, BookOpen,
  Handshake, AlertTriangle, Landmark, Briefcase
} from 'lucide-react';

const expertiseAreas = [
  {
    icon: Heart,
    title: 'Divorce Lawyer',
    shortDesc: 'Compassionate and strategic divorce legal services.',
    fullDesc: 'Going through a divorce is one of the most challenging experiences in life. Our divorce lawyers handle every aspect of divorce proceedings including mutual consent divorce, contested divorce, annulment, and separation agreements. We ensure your rights are protected while striving for an amicable resolution whenever possible.',
    keyAreas: ['Mutual Consent Divorce', 'Contested Divorce', 'Annulment Proceedings', 'Separation Agreements', 'Alimony & Maintenance', 'Division of Assets'],
  },
  {
    icon: Shield,
    title: 'Domestic Violence Lawyer',
    shortDesc: 'Fighting for the safety and rights of victims.',
    fullDesc: 'Domestic violence cases require sensitivity, urgency, and strong legal action. Our experienced domestic violence lawyers help victims file complaints under the Protection of Women from Domestic Violence Act, obtain protection orders, and pursue legal remedies to ensure safety and justice.',
    keyAreas: ['Filing DV Act Complaints', 'Protection Orders', 'Residence Orders', 'Monetary Relief', 'Custody Orders', 'Criminal Proceedings'],
  },
  {
    icon: Handshake,
    title: 'Matrimonial Lawyer',
    shortDesc: 'Expert handling of all matrimonial legal matters.',
    fullDesc: 'Matrimonial disputes encompass a wide range of legal issues from marriage registration to divorce. Our matrimonial lawyers specialize in all aspects of matrimonial law, providing comprehensive legal support for marriage-related disputes, dowry cases, and matrimonial counseling referrals.',
    keyAreas: ['Marriage Registration', 'Dowry Cases', 'Restitution of Conjugal Rights', 'Nullity of Marriage', 'Matrimonial Disputes', 'Inter-Caste Marriage Issues'],
  },
  {
    icon: Users,
    title: 'Family Disputes Lawyer',
    shortDesc: 'Resolving family conflicts with care and legal expertise.',
    fullDesc: 'Family disputes can be emotionally draining and legally complex. Our family dispute lawyers handle inheritance disputes, property partition among family members, maintenance claims, and all other family-related legal matters with empathy and professionalism.',
    keyAreas: ['Inheritance & Succession', 'Property Partition', 'Maintenance Claims', 'Guardianship', 'Adoption Proceedings', 'Family Mediation'],
  },
  {
    icon: Lock,
    title: 'Bail Matters Lawyer',
    shortDesc: 'Swift and effective bail representation in all courts.',
    fullDesc: 'Getting bail at the right time can make all the difference. Our bail matter lawyers have extensive experience in securing regular bail, anticipatory bail, and interim bail across all courts in Delhi. We act swiftly to protect your liberty and ensure a strong defense.',
    keyAreas: ['Regular Bail', 'Anticipatory Bail', 'Interim Bail', 'Bail in Economic Offences', 'Bail in NDPS Cases', 'Bail Cancellation Defense'],
  },
  {
    icon: FileText,
    title: 'Cheque Bounce Lawyer',
    shortDesc: 'Efficient resolution of cheque bounce cases.',
    fullDesc: 'Cheque bounce cases under Section 138 of the Negotiable Instruments Act require prompt legal action. Our cheque bounce lawyers handle both filing and defending cheque bounce cases, ensuring timely compliance with legal notices and effective representation in court.',
    keyAreas: ['Section 138 NI Act Cases', 'Legal Notice Drafting', 'Filing Complaints', 'Defending Complaints', 'Summary Trial', 'Appeal & Revision'],
  },
  {
    icon: Gavel,
    title: 'Civil Lawyer',
    shortDesc: 'Comprehensive civil litigation and dispute resolution.',
    fullDesc: 'Civil law covers a vast range of disputes from property matters to contractual issues. Our civil lawyers bring deep expertise in civil suits, injunctions, specific performance, recovery suits, and all forms of civil litigation. We aim for efficient resolution through both court proceedings and alternative dispute resolution.',
    keyAreas: ['Civil Suits & Recovery', 'Injunction & Stay Orders', 'Specific Performance', 'Contractual Disputes', 'Debt Recovery', 'Alternative Dispute Resolution'],
  },
  {
    icon: AlertTriangle,
    title: 'Criminal Lawyer',
    shortDesc: 'Aggressive criminal defense to protect your rights.',
    fullDesc: 'Criminal charges can have life-altering consequences. Our criminal defense lawyers provide robust representation in all types of criminal cases including FIR registration, quashing petitions, criminal appeals, and defense against charges ranging from white-collar crimes to serious offences.',
    keyAreas: ['FIR & Criminal Complaints', 'Quashing Petitions', 'Criminal Appeals', 'White Collar Crimes', 'Cyber Crimes', 'Anticipatory & Regular Bail'],
  },
  {
    icon: Landmark,
    title: 'Supreme Court Lawyer',
    shortDesc: 'Expert representation at the highest court of India.',
    fullDesc: 'Appearing before the Supreme Court of India requires exceptional legal acumen and preparation. Our Supreme Court lawyers have extensive experience in filing Special Leave Petitions (SLPs), appeals, and writ petitions. We provide thorough case analysis and strategic representation at the apex court.',
    keyAreas: ['Special Leave Petitions', 'Writ Petitions', 'Criminal Appeals', 'Civil Appeals', 'Public Interest Litigation', 'Review Petitions'],
  },
  {
    icon: Building,
    title: 'Corporate Lawyer',
    shortDesc: 'Strategic corporate legal advisory and compliance.',
    fullDesc: 'In today\'s complex business environment, having the right corporate legal partner is essential. Our corporate lawyers advise businesses on company formation, regulatory compliance, mergers & acquisitions, corporate governance, and commercial contracts. We help businesses navigate legal complexities with confidence.',
    keyAreas: ['Company Incorporation', 'Mergers & Acquisitions', 'Corporate Governance', 'Commercial Contracts', 'Regulatory Compliance', 'Due Diligence'],
  },
];

const OurExpertise = () => {
  return (
    <div>
      {/* Hero */}
      <section className="hero-gradient py-20 md:py-28">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="inline-flex items-center gap-2 bg-accent/20 text-accent px-4 py-2 rounded-full text-sm font-medium mb-6">
            <Scale size={16} />
            Our Expertise
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4" style={{ fontFamily: 'Georgia, serif' }}>
            Areas of Legal Expertise
          </h1>
          <p className="text-gray-300 max-w-2xl mx-auto text-lg">
            With specialized knowledge across 10 major practice areas, we deliver comprehensive legal solutions tailored to your unique situation.
          </p>
        </div>
      </section>

      {/* Overview */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="bg-lighter rounded-2xl p-8 md:p-12 text-center border border-gray-100">
            <h2 className="text-2xl md:text-3xl font-bold text-primary mb-4" style={{ fontFamily: 'Georgia, serif' }}>
              10 Specialized Practice Areas. One Dedicated Team.
            </h2>
            <p className="text-gray-600 max-w-3xl mx-auto leading-relaxed">
              At Legal Edge Associates, our expertise spans across diverse legal domains. Each practice area is led by experienced lawyers who bring deep domain knowledge and a proven track record. Whether you need assistance with a family dispute or corporate matter, we have the expertise to help.
            </p>
          </div>
        </div>
      </section>

      {/* Expertise Areas */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="space-y-12">
            {expertiseAreas.map((area, index) => (
              <div
                key={index}
                className={`grid md:grid-cols-2 gap-8 items-center ${
                  index % 2 === 1 ? 'md:direction-rtl' : ''
                }`}
              >
                <div className={index % 2 === 1 ? 'md:order-2' : ''}>
                  <div className="bg-primary rounded-2xl p-10 text-center h-full flex flex-col items-center justify-center">
                    <div className="bg-accent/20 w-20 h-20 rounded-full flex items-center justify-center mb-4">
                      <area.icon className="text-accent" size={40} />
                    </div>
                    <h3 className="text-white text-2xl font-bold mb-2" style={{ fontFamily: 'Georgia, serif' }}>
                      {area.title}
                    </h3>
                    <p className="text-accent text-sm font-medium">{area.shortDesc}</p>
                  </div>
                </div>
                <div className={index % 2 === 1 ? 'md:order-1' : ''}>
                  <span className="text-accent font-semibold text-sm tracking-wider uppercase">
                    Practice Area {String(index + 1).padStart(2, '0')}
                  </span>
                  <h3 className="text-2xl md:text-3xl font-bold text-primary mt-2 mb-4" style={{ fontFamily: 'Georgia, serif' }}>
                    {area.title}
                  </h3>
                  <p className="text-gray-600 mb-6 leading-relaxed">{area.fullDesc}</p>
                  <div className="grid grid-cols-2 gap-3 mb-6">
                    {area.keyAreas.map((item, i) => (
                      <div key={i} className="flex items-center gap-2 text-sm text-gray-700">
                        <CheckCircle className="text-accent shrink-0" size={16} />
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                  <Link
                    to="/contact"
                    className="inline-flex items-center gap-2 bg-accent hover:bg-accent-light text-white px-6 py-3 rounded-md font-semibold transition-all duration-300 text-sm"
                  >
                    Consult Our {area.title}
                    <ChevronRight size={16} />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-lighter">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-14">
            <span className="text-accent font-semibold text-sm tracking-wider uppercase">Why Choose Us</span>
            <h2 className="text-3xl md:text-4xl font-bold text-primary mt-2 mb-4" style={{ fontFamily: 'Georgia, serif' }}>
              What Sets Us Apart
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { icon: Briefcase, title: 'Specialized Knowledge', desc: 'Each lawyer focuses on specific practice areas, ensuring deep expertise and up-to-date knowledge of relevant laws and precedents.' },
              { icon: BookOpen, title: 'Research-Driven Approach', desc: 'We back every case with thorough legal research, ensuring no stone is left unturned in building your case.' },
              { icon: Scale, title: 'Proven Track Record', desc: 'With a 95% success rate across 2000+ cases, our results speak for themselves. We deliver outcomes, not just promises.' },
            ].map((item, index) => (
              <div key={index} className="bg-white rounded-xl p-8 card-hover shadow-sm border border-gray-100 text-center">
                <div className="bg-accent/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <item.icon className="text-accent" size={30} />
                </div>
                <h3 className="text-lg font-bold text-primary mb-3">{item.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-primary">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4" style={{ fontFamily: 'Georgia, serif' }}>
            Need Expert Legal Help?
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto mb-8">
            Whatever your legal challenge, our team of specialized lawyers is ready to help you navigate it with confidence.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link
              to="/contact"
              className="bg-accent hover:bg-accent-light text-white px-8 py-3.5 rounded-md font-semibold transition-all duration-300 shadow-lg flex items-center gap-2"
            >
              Get Free Consultation
              <ArrowRight size={18} />
            </Link>
            <Link
              to="/our-services"
              className="border-2 border-white/30 hover:border-accent text-white px-8 py-3.5 rounded-md font-semibold transition-all duration-300"
            >
              View Our Services
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default OurExpertise;
